<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('inicio', function () {
    return view('inicio');
});

Route::get('predey', function () {
    return view('predey');
});

//login y registro
Route::post('/inicio', 'AdminController@login')->name('login');
Route::post('/predey', 'EmpleadoController@login')->name('predey');
Route::post('/registrarAdmin', 'AdminController@registrar')->name('registrar.admin');


//registros desde el sitio
Route::post('/registrarEmpresa', 'EmpresaController@registrar')->name('registrar.empresa');
Route::post('/registrarCliente', 'EmpleadoEmpresaController@registrar')->name('registrar.empleadoEmpresa');
Route::post('/registrarEmpleado', 'EmpleadoController@registrar')->name('registrar.empleado');


//actualizaciones desde el sitio
Route::post('/actualizarEmpleado/{id}', 'EmpleadoEmpresaController@actualizar')->name('actualizarEmpleado');
Route::post('/actualizarEmpleado1/{id}/{ide}', 'EmpleadoEmpresaController@actualizar1')->name('actualizarEmpleado1');

Route::post('/actualizarEmpresa/{id}', 'EmpresaController@actualizar')->name('actualizarEmpresa');

Route::post('/actualizarAdmin/{id}', 'AdminController@actualizar')->name('actualizarAdmin');
Route::post('/actualizarCliente/{id}', 'EmpleadoController@actualizar')->name('actualizarCliente');

Route::post('/solicitarCredito/{id}/{pp}', 'CreditoController@solicitar')->name('solicitarCredito');
Route::get('/creditos', 'CreditoController@ver')->name('creditos');


//direccionamiento a paginas
Route::get('/', 'login@login')->name('index');
Route::get('/altaEmpresa', 'EmpresaController@index')->name('altaEmpresas');
Route::get('/altaCliente', 'EmpleadoEmpresaController@index')->name('altaCliente');

Route::get('/activar1/{id}/{ide}', 'EmpleadoEmpresaController@activar1')->name('activar1');
Route::get('/desactivar1/{id}/{ide}', 'EmpleadoEmpresaController@desactivar1')->name('desactivar1');

Route::get('/activar/{id}', 'EmpleadoEmpresaController@activar')->name('activar');
Route::get('/desactivar/{id}', 'EmpleadoEmpresaController@desactivar')->name('desactivar');

Route::get('/eliminarEmpleado/{id}', 'EmpleadoEmpresaController@eliminar')->name('eliminarEmpleado');
Route::get('/eliminarEmpleado1/{id}/{ide}', 'EmpleadoEmpresaController@eliminar1')->name('eliminarEmpleado1');

Route::get('/eliminarEmpresa/{id}', 'EmpresaController@eliminar')->name('eliminarEmpresa');

Route::get('/misCreditos/{id}', 'CreditoController@index')->name('misCreditos');


//paypal
Route::get('/paypal/pay', 'PaymentController@payWithPayPal');
Route::get('/paypal/status', 'PaymentController@payPalStatus');