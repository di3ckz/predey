<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class credito extends Model
{
    protected $table = 'creditos';
}
