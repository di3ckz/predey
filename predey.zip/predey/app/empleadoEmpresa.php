<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class empleadoEmpresa extends Model
{
    protected $table = 'empleado_empresas';
}
