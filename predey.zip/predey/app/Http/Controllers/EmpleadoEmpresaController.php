<?php

namespace App\Http\Controllers;

use App\empleadoEmpresa;
use Illuminate\Http\Request;

class EmpleadoEmpresaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $empleadoEmpresas = \DB::table('empleado_empresas')
                    ->select('empleado_empresas.*')
                    ->orderBy('id','DESC')
                    ->get();

        $empresas = \DB::table('empresas')
                    ->select('empresas.*')
                    ->orderBy('id','DESC')
                    ->get();

        return view('altaCliente')->with('empleadoEmpresas',$empleadoEmpresas)->with('empresas',$empresas);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function registrar(Request $request)
    {
        $cont = \DB::table('empleado_empresas')
                    ->where('noEmpleado', '=', $request->noEmpleado)
                    ->where('idEmpresa', '=', $request->idEmpresa)
                    ->count();

        if($cont != 0){
            return back()->with('respuestaerror', 'Error, al parecer el número de empleado ya esta registrado para esta empresa');
        }else{
            $dato = new \App\empleadoEmpresa;
            $dato->idEmpleado = "";
            $dato->noEmpleado = $request->noEmpleado;
            $dato->salario = $request->salario;
            $dato->cargo = $request->cargo;
            $dato->idEmpresa = $request->idEmpresa;
            $dato->estado = "activo";

            if($dato->save()){
                return back()->with('respuesta', 'Cliente registrado');
            }else{
                return back()->with('respuestaerror', 'Error al registrar, intente una vez más');
            }
        }
    }

    public function activar($id)
    {

        $app = empleadoEmpresa::find($id);
        $app->estado = "activo";
        $app->save();

        return back();
    }

    public function desactivar($id)
    {
        $app = empleadoEmpresa::find($id);
        $app->estado = "inactivo";
        $app->save();

        return back();
    }

    public function activar1($id, $ide)
    {

        $app = empleadoEmpresa::find($id);
        $app->estado = "activo";
        $app->save();

        $app1 = \App\empleado::find($ide);
        $app1->estado = "activo";
        $app1->save();

        return back();
    }

    public function desactivar1($id, $ide)
    {
        $app = empleadoEmpresa::find($id);
        $app->estado = "inactivo";
        $app->save();

        $app1 = \App\empleado::find($ide);
        $app1->estado = "inactivo";
        $app1->save();

        return back();
    }

    public function actualizar(Request $request, $id)
    {   
        $app = empleadoEmpresa::find($id);

        if($app->noEmpleado != $request->noEmpleado || $app->idEmpresa != $request->idEmpresa){
            $cont = \DB::table('empleado_empresas')
                        ->where('noEmpleado', '=', $request->noEmpleado)
                        ->where('idEmpresa', '=', $request->idEmpresa)
                        ->count();

            if($cont != 0){
                return back()->with('respuestaerror', 'Error, al parecer el número de empleado ya esta registrado para esta empresa');
            }else{
                $empleadoe = empleadoEmpresa::find($id);
                $empleadoe->noEmpleado = $request->noEmpleado;
                $empleadoe->salario = $request->salario;
                $empleadoe->cargo = $request->cargo;
                $empleadoe->idEmpresa = $request->idEmpresa;

                if($empleadoe->save()){
                    return back()->with('respuesta', 'Datos actualizados');
                }else{
                    return back()->with('respuestaerror', 'Error al actualizar');
                }
            }
        }else{
            
            $empleadoe = empleadoEmpresa::find($id);
            
            $empleadoe->salario = $request->salario;
            $empleadoe->cargo = $request->cargo;

            if($empleadoe->save()){
                return back()->with('respuesta', 'Datos actualizados');
            }else{
                return back()->with('respuestaerror', 'Error al actualizar');
            }
            
        }
    }

    public function actualizar1(Request $request, $id, $ide)
    {   
        $cont = \DB::table('empleado_empresas')
                    ->where('noEmpleado', '=', $request->noEmpleado)
                    ->where('idEmpresa', '=', $request->idEmpresa)
                    ->count();

        if($cont != 0){
            return back()->with('respuestaerror', 'Error, al parecer el número de empleado ya esta registrado para esta empresa');
        }else{
            $empleadoe = empleadoEmpresa::find($id);
            $empleadoe->noEmpleado = $request->noEmpleado;
            $empleadoe->salario = $request->salario;
            $empleadoe->cargo = $request->cargo;
            $empleadoe->idEmpresa = $request->idEmpresa;

            $empleadoe1 = \App\empleado::find($ide);
            $empleadoe1->idEmpleado = $request->noEmpleado;
            $empleadoe1->idEmpresa = $request->idEmpresa;

            if($empleadoe->save() && $empleadoe1->save()){
                return back()->with('respuesta', 'Datos actualizados');
            }else{
                return back()->with('respuestaerror', 'Error al actualizar');
            }
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function eliminar($id)
    {
        $app = empleadoEmpresa::find($id);
        $app->delete();

        return back()->with('respuesta', 'Registro eliminado con exito');
    }

    public function eliminar1($id, $ide)
    {
        $app = empleadoEmpresa::find($id);
        $app->delete();

        $app = \App\empleado::find($ide);
        $app->delete();

        return back()->with('respuesta', 'Registro eliminado con exito');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\empleadoEmpresa  $empleadoEmpresa
     * @return \Illuminate\Http\Response
     */
    public function show(empleadoEmpresa $empleadoEmpresa)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\empleadoEmpresa  $empleadoEmpresa
     * @return \Illuminate\Http\Response
     */
    public function edit(empleadoEmpresa $empleadoEmpresa)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\empleadoEmpresa  $empleadoEmpresa
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, empleadoEmpresa $empleadoEmpresa)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\empleadoEmpresa  $empleadoEmpresa
     * @return \Illuminate\Http\Response
     */
    public function destroy(empleadoEmpresa $empleadoEmpresa)
    {
        //
    }
}
