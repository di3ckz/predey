<?php

namespace App\Http\Controllers;

use App\admin;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
        $cont = \DB::table('admins')
                    ->where('correo', '=', $request->correo)
                    ->where('contraseña', '=', $request->contraseña)
                    ->count();
        if($cont != 0){
                    session ( [ 
                        'usuario' => $request->get ( 'correo' )
                    ] );
                    return view('inicio');
        }else{
            $cont2 = \DB::table('empleados')
                        ->where('correo', '=', $request->correo)
                        ->where('contraseña', '=', $request->contraseña)
                        ->count();
            if($cont2 != 0){

                        session ( [ 
                            'usuario' => $request->get ( 'correo' )
                        ] );

                        return redirect()->route('predey');
            }else{
                return back()->with('respuestaerror', 'Error al iniciar sesión, datos incorrectos, intente una vez más.')->withInput($request->except('contraseña'));
            }
        }
    }

    public function registrar(Request $request){

        $cont = \DB::table('admins')
                    ->where('correo', '=', $request->correo)
                    ->count();

        if($cont != 0){
            return back()->with('respuestaerror', 'Error al registrar, al parecer el correo ya esta vinculado a otra cuenta')->withInput($request->except('correo'));
        }else{
            if($request->contraseña == "predey:1234"){
                $dato = new \App\admin;   
                $dato->nombre = $request->nombre;
                $dato->apaterno = $request->apaterno;
                $dato->amaterno = $request->amaterno;
                $dato->telefono = $request->telefono;
                $dato->correo = $request->correo;
                $dato->contraseña = $request->contraseña;

                if($dato->save()){
                    return back()->with('respuesta', 'Usuario registrado');
                }else{
                    return back()->with('respuestaerror', 'Error al registrar, intente una vez más')->withInput();
                }
            }else{
                return back()->with('respuestaerror', 'Error, registre la contraseña proporcionada por Predey')->withInput($request->except('contraseña'));
            }
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function actualizar(Request $request, $id)
    {
        if($request->contraseña != ""){
            $cont = \DB::table('admins')
                    ->where('id', '=', $request->id)
                    ->where('contraseña', '=', $request->contraseña)
                    ->count();
            if($cont != 0){
                $app = admin::find($id);
                if($app->correo != $request->correo){
                    $cont = \DB::table('amins')
                            ->where('correo', '=', $request->correo)
                            ->count();
                    if($cont != 0 ){
                        return back()->with('respuestaerror', 'Error, el correo ya se encuentra registrado para otra cuenta');
                    }else{
                        $app = admin::find($id);
                        $app->nombre = $request->nombre;
                        $app->apaterno = $request->apaterno;
                        $app->amaterno = $request->amaterno;
                        $app->correo = $request->correo;
                        $app->telefono = $request->telefono;
                        $app->contraseña = $request->ncontraseña;

                        if($app->save()){
                            return redirect()->route('index')->with('respuesta', 'Datos actualizados correctamente, tan solo ingrese una vez más a Predey con los cambios previamente realizados');
                        }else{
                            return back()->with('respuestaerror', 'Error al actualizar datos');
                        }
                    }
                }else{
                    $app = admin::find($id);
                    $app->nombre = $request->nombre;
                    $app->apaterno = $request->apaterno;
                    $app->amaterno = $request->amaterno;
                    $app->telefono = $request->telefono;
                    $app->contraseña = $request->ncontraseña;

                    if($app->save()){
                        return back()->with('respuesta', 'Datos actualizados correctamente');
                    }else{
                        return back()->with('respuestaerror', 'Error al actualizar datos');
                    }
                }
            }else{
                return back()->with('respuestaerror', 'La contraseña ingresada es incorrecta');
            }
        }else{
            $app = admin::find($id);
            if($app->correo != $request->correo){
                $cont = \DB::table('admins')
                        ->where('correo', '=', $request->correo)
                        ->count();
                if($cont != 0){
                    return back()->with('respuestaerror', 'Error, el correo ya se encuentra registrado para otra cuenta');
                }else{
                    $app = admin::find($id);
                    $app->nombre = $request->nombre;
                    $app->apaterno = $request->apaterno;
                    $app->amaterno = $request->amaterno;
                    $app->correo = $request->correo;
                    $app->telefono = $request->telefono;

                    if($app->save()){
                        return redirect()->route('index')->with('respuesta', 'Datos actualizados correctamente, tan solo ingrese una vez más a Predey con los cambios previamente realizados');
                    }else{
                        return back()->with('respuestaerror', 'Error al actualizar datos');
                    }
                }
            }else{
                $app = admin::find($id);
                $app->nombre = $request->nombre;
                $app->apaterno = $request->apaterno;
                $app->amaterno = $request->amaterno;
                $app->telefono = $request->telefono;

                if($app->save()){
                    return back()->with('respuesta', 'Datos actualizados correctamente');
                }else{
                    return back()->with('respuestaerror', 'Error al actualizar datos');
                }
            }
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function show(admin $admin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function edit(admin $admin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, admin $admin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function destroy(admin $admin)
    {
        //
    }
}
