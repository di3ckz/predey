<?php

namespace App\Http\Controllers;

use App\empresa;
use Illuminate\Http\Request;

class EmpresaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $empresas = \DB::table('empresas')
                    ->select('empresas.*')
                    ->orderBy('id','DESC')
                    ->get();
        return view('altaEmpresas')->with('empresas',$empresas);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function registrar(Request $request)
    {
        $cont = \DB::table('empresas')
                    ->where('nempresa', '=', $request->nempresa)
                    ->count();

        if($cont != 0){
            return back()->with('respuestaerror', 'Error al registrar, al parecer la empresa ya esta registrada');
        }else{
            $dato = new \App\empresa;   
            $dato->nempresa = $request->nempresa;
            $dato->direccion = $request->direccion;
            $dato->periodoPago = $request->periodoPago;
            $dato->estado = "";

            if($dato->save()){
                return back()->with('respuesta', 'Empresa registrada con exito');
            }else{
                return back()->with('respuestaerror', 'Error al registrar, intente una vez más');
            }
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function actualizar(Request $request, $id)
    {   
        $app = empresa::find($id);
        if($app->nempresa != $request->nempresa){
            $cont = \DB::table('empresas')
                    ->where('nempresa', '=', $request->nempresa)
                    ->count();

            if($cont != 0){
                return back()->with('respuestaerror', 'Error, al parecer ya existe una empresa registrada con ese nombre');
            }else{
                $app = empresa::find($id);
                $app->nempresa = $request->nempresa;
                $app->direccion = $request->direccion;
                $app->periodoPago = $request->periodoPago;
                $app->save();
                
                if($app->save()){
                    return back()->with('respuesta', 'Datos actualizados');
                }else{
                    return back()->with('respuestaerror', 'Error al actualizar');
                }
            }
        }else{
            $app = empresa::find($id);
            $app->nempresa = $request->nempresa;
            $app->direccion = $request->direccion;
            $app->periodoPago = $request->periodoPago;
            $app->save();
            
            if($app->save()){
                return back()->with('respuesta', 'Datos actualizados');
            }else{
                return back()->with('respuestaerror', 'Error al actualizar');
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\empresa  $empresa
     * @return \Illuminate\Http\Response
     */
    public function eliminar($id)
    {
        $cont = \DB::table('empleado_empresas')
                    ->where('idEmpresa', '=', $id)
                    ->count();

        if($cont != 0){
            return back()->with('respuestaerror', 'Error, el registro de la empresa no puede ser eliminado debido a que hay empleados que estan registrados a la misma, para poder eliminar antes se deben eliminar dichos registros de empleados en el apartado de alta de cleintes');
        }else{
            $app = empresa::find($id);

            if($app->delete()){
                return back()->with('respuesta', 'Registro eliminado exitosamente');
            }
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\empresa  $empresa
     * @return \Illuminate\Http\Response
     */
    public function edit(empresa $empresa)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\empresa  $empresa
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, empresa $empresa)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\empresa  $empresa
     * @return \Illuminate\Http\Response
     */
    public function destroy(empresa $empresa)
    {
        //
    }
}
