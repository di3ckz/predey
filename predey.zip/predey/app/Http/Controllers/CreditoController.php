<?php

namespace App\Http\Controllers;

use App\credito;
use Illuminate\Http\Request;

class CreditoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function solicitar(Request $request, $id, $pp)
    {   
        $cont = \DB::table('creditos')
                    ->where('idEmpleado', '=', $id)
                    ->count();
        if($cont != 0){
            return back()->with('respuestaerror', 'Lo sentimos, al parcer aun cuentas con un credito vigente');
        }else{
            $nfecha = date("d-m-Y");
            $pp = $pp;
            if($pp != "Catorcenal" && $pp != "Quincenal"){
                switch($pp){
                    case "Semanal":
                        $selector = "week";
                    break;
                    case "Mensual":
                        $selector = "month";
                    break;
                }
                for($i = 0; $i < $request->plazoPago; $i++){
                    $dato = new \App\credito;
                    $dato->idEmpleado = $id;
                    $dato->periodoPago = $pp;
                    $dato->duracion = $request->plazoPago;
                    $dato->monto = $request->montoCredito;
                    
                    $cadaPago = ($request->montoCredito+($request->montoCredito * 0.08))/$request->plazoPago;
        
                    $dato->cpago = round($cadaPago,2);
                    $dato->fpago = date("d-m-Y",strtotime($nfecha."+ ".($i)." ".$selector.""));
                    
                    $dato->tpagar = ($request->montoCredito+($request->montoCredito * 0.08));
                    $dato->estado = "pendiente";
                    
                    $dato->save();
                }
            }else{
                if($pp == "Catorcenal"){
                    $days = 14;
                    for($i = 0; $i < $request->plazoPago; $i++){
                        $dato = new \App\credito;
                        $dato->idEmpleado = $id;
                        $dato->periodoPago = $pp;
                        $dato->duracion = $request->plazoPago;
                        $dato->monto = $request->montoCredito;
                        
                        $cadaPago = ($request->montoCredito+($request->montoCredito * 0.08))/$request->plazoPago;
            
                        $dato->cpago = round($cadaPago,2);
                        $dato->fpago = date("d-m-Y",strtotime($nfecha."+ ".($i*$days)." days"));
            
                        $dato->tpagar = ($request->montoCredito+($request->montoCredito * 0.08));
                        $dato->estado = "pendiente";
                        
                        $dato->save();
                    }
                }else{
                    if($pp == "Quincenal"){
                        for($i = 0; $i < $request->plazoPago; $i++){
                            $dato = new \App\credito;
                            $dato->idEmpleado = $id;
                            $dato->periodoPago = $pp;
                            $dato->duracion = $request->plazoPago;
                            $dato->monto = $request->montoCredito;
                            
                            $cadaPago = ($request->montoCredito+($request->montoCredito * 0.08))/$request->plazoPago;
                
                            $dato->cpago = round($cadaPago,2);
                            $dato->fpago = date("d-m-Y",strtotime($nfecha."+ ".($i*2)." week"));
                
                            $dato->tpagar = ($request->montoCredito+($request->montoCredito * 0.08));
                            $dato->estado = "pendiente";
                            
                            $dato->save();
                        }
                    }
                }
                
            }
            return back()->with('respuesta', 'Credito solicitado');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {   
        $creditos = \DB::table('creditos')
                    ->where('idEmpleado', '=', $id)
                    ->get();
        return view('misCreditos')->with('creditos',$creditos);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function ver()
    {
        $creditos = \DB::table('creditos')
                    ->select('creditos.*')
                    ->get();
        return view('creditos')->with('creditos',$creditos);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\credito  $credito
     * @return \Illuminate\Http\Response
     */
    public function show(credito $credito)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\credito  $credito
     * @return \Illuminate\Http\Response
     */
    public function edit(credito $credito)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\credito  $credito
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, credito $credito)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\credito  $credito
     * @return \Illuminate\Http\Response
     */
    public function destroy(credito $credito)
    {
        //
    }
}
