<?php

namespace App\Http\Controllers;

use App\empleado;
use Illuminate\Http\Request;

class EmpleadoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
       return view('predey');
    }

    public function registrar(Request $request){

        $cont = \DB::table('empleados')
                    ->where('correo', '=', $request->correo)
                    ->count();

        if($cont != 0){
            return back()->with('respuestaerror', 'Error al registrar, al parecer  el correo ya esta vinculado a otra cuenta')->withInput($request->except('correo'));
        }else{
            $cont1 = \DB::table('empleados')
                    ->where('idEmpleado', '=', $request->noEmpleado)
                    ->where('idEmpresa', '=', $request->idEmpresa)
                    ->count();
            if($cont1 != 0){
                return back()->with('respuestaerror', 'Error, al parecer ya hay un registro con ese número de empleado para su empresa')->withInput($request->except('noEmpleado'));
            }else{
                $cont2 = \DB::table('empleado_empresas')
                    ->where('noEmpleado', '=', $request->noEmpleado)
                    ->where('idEmpresa', '=', $request->idEmpresa)
                    ->where('estado', '=', "activo")
                    ->count();

                if($cont2 != 0){
                    $dato = new \App\empleado;
                    $dato->nombre = $request->nombre;
                    $dato->apaterno = $request->apaterno;
                    $dato->amaterno = $request->amaterno;
                    $dato->telefono = $request->telefono;
                    $dato->idEmpleado = $request->noEmpleado;
                    $dato->idEmpresa = $request->idEmpresa;
                    $dato->correo = $request->correo;
                    $dato->contraseña = $request->contraseña;
                    $dato->estado = "activo";

                    if($dato->save()){
                        return back()->with('respuesta', 'Usuario registrado');
                    }else{
                        return back()->with('respuestaerror', 'Error al registrar, intente una vez más')->withInput();
                    }
                }else{
                    return back()->with('respuestaerror', 'Error, al parecer aun no puede realizar el registro espere un poco más')->withInput();
                }
            }
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function actualizar(Request $request, $id)
    {
        if($request->contraseña != ""){
            $cont = \DB::table('empleados')
                    ->where('id', '=', $request->id)
                    ->where('contraseña', '=', $request->contraseña)
                    ->count();
            if($cont != 0){
                $app = empleado::find($id);
                if($app->correo != $request->correo){
                    $cont = \DB::table('empleados')
                            ->where('correo', '=', $request->correo)
                            ->count();
                    if($cont != 0 ){
                        return back()->with('respuestaerror', 'Error, el correo ya se encuentra registrado para otra cuenta');
                    }else{
                        $app = empleado::find($id);
                        $app->nombre = $request->nombre;
                        $app->apaterno = $request->apaterno;
                        $app->amaterno = $request->amaterno;
                        $app->correo = $request->correo;
                        $app->telefono = $request->telefono;
                        $app->contraseña = $request->ncontraseña;

                        if($app->save()){
                            return redirect()->route('index')->with('respuesta', 'Datos actualizados correctamente, tan solo ingrese una vez más a Predey con los cambios previamente realizados');
                        }else{
                            return back()->with('respuestaerror', 'Error al actualizar datos');
                        }
                    }
                }else{
                    $app = empleado::find($id);
                    $app->nombre = $request->nombre;
                    $app->apaterno = $request->apaterno;
                    $app->amaterno = $request->amaterno;
                    $app->telefono = $request->telefono;
                    $app->contraseña = $request->ncontraseña;

                    if($app->save()){
                        return back()->with('respuesta', 'Datos actualizados correctamente');
                    }else{
                        return back()->with('respuestaerror', 'Error al actualizar datos');
                    }
                }
            }else{
                return back()->with('respuestaerror', 'La contraseña ingresada es incorrecta');
            }
        }else{
            $app = empleado::find($id);
            if($app->correo != $request->correo){
                $cont = \DB::table('empleados')
                        ->where('correo', '=', $request->correo)
                        ->count();
                if($cont != 0){
                    return back()->with('respuestaerror', 'Error, el correo ya se encuentra registrado para otra cuenta');
                }else{
                    $app = empleado::find($id);
                    $app->nombre = $request->nombre;
                    $app->apaterno = $request->apaterno;
                    $app->amaterno = $request->amaterno;
                    $app->correo = $request->correo;
                    $app->telefono = $request->telefono;
                }
            }else{
                $app = empleado::find($id);
                $app->nombre = $request->nombre;
                $app->apaterno = $request->apaterno;
                $app->amaterno = $request->amaterno;
                $app->telefono = $request->telefono;

                if($app->save()){
                    return back()->with('respuesta', 'Datos actualizados correctamente');
                }else{
                    return back()->with('respuestaerror', 'Error al actualizar datos');
                }
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function show(empleado $empleado)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function edit(empleado $empleado)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, empleado $empleado)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function destroy(empleado $empleado)
    {
        //
    }
}
