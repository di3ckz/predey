<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class login extends Controller
{
    public function login()
    {
        $empresas = \DB::table('empresas')
                    ->select('empresas.*')
                    ->orderBy('id','DESC')
                    ->get();
        return view('index')->with('empresas',$empresas);
    }
}