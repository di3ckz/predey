create table empresas(
	id,
	nombre,
	tipo,
	ubicacion,
	telefono,
	correo,
	clasificacion_nomina
);

create table empleados(
	id,
	nombre,
	apaterno,
	amaterno,
	telefono,
	correo,
	direccion,
	sexo,
	contraseña
);

create table empleado_empresa(
	id,
	id_empleado,
	id_empresa,
	cargo,
	salario
);

create table adelantos(
	id,
	id_empleado,
	monto,
	fecha_in,
	fecha_fn
);

create table creditos(
	id,
	id_empleado,
	credito,
	fecha_in,
	fecha_fn,
	porcentaje,
	ganancia
);

create table negocio_empresa(
	id,
	id_empresa,
	relacion_pago
);